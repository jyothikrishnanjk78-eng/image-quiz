export interface GuessItem {
  id: string;
  name: string;
  imageDataUrl: string;
  createdAt: number;
  width?: number;
  height?: number;
}

export type AspectRatioType = 'free' | '1:1' | '4:3' | '16:9';

export interface CropSettings {
  x: number;
  y: number;
  width: number;
  height: number;
}
