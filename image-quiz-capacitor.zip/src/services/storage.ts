import { GuessItem } from '../types';

const DB_NAME = 'snap_guess_offline_db';
const DB_VERSION = 1;
const STORE_NAME = 'items';

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !('indexedDB' in window)) {
      reject(new Error('IndexedDB not supported'));
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

// Fallback to localStorage in case IndexedDB fails in strict private modes
const LS_BACKUP_KEY = 'snap_guess_backup_items';

function fallbackGet(): GuessItem[] {
  try {
    const raw = localStorage.getItem(LS_BACKUP_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function fallbackSave(items: GuessItem[]): void {
  try {
    localStorage.setItem(LS_BACKUP_KEY, JSON.stringify(items));
  } catch {
    // LocalStorage quota might be exceeded if images are huge
  }
}

export async function getAllGuessItems(): Promise<GuessItem[]> {
  try {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const request = store.getAll();

      request.onsuccess = () => {
        const items = request.result as GuessItem[];
        // Sort newest first
        items.sort((a, b) => b.createdAt - a.createdAt);
        resolve(items);
      };
      request.onerror = () => reject(request.error);
    });
  } catch {
    return fallbackGet();
  }
}

export async function saveGuessItem(item: GuessItem): Promise<void> {
  try {
    const db = await openDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const request = store.put(item);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch {
    const items = fallbackGet().filter((i) => i.id !== item.id);
    items.unshift(item);
    fallbackSave(items);
  }
}

export async function saveManyGuessItems(newItems: GuessItem[]): Promise<void> {
  try {
    const db = await openDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      for (const item of newItems) {
        store.put(item);
      }
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    const existing = fallbackGet();
    const map = new Map(existing.map((item) => [item.id, item]));
    for (const item of newItems) {
      map.set(item.id, item);
    }
    fallbackSave(Array.from(map.values()));
  }
}

export async function deleteGuessItem(id: string): Promise<void> {
  try {
    const db = await openDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const request = store.delete(id);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch {
    const filtered = fallbackGet().filter((i) => i.id !== id);
    fallbackSave(filtered);
  }
}

export async function clearAllGuessItems(): Promise<void> {
  try {
    const db = await openDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const request = store.clear();
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch {
    fallbackSave([]);
  }
}
