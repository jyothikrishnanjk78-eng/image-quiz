import React, { useState, useEffect, useRef, useCallback } from 'react';
import { RotateCw, RotateCcw, ZoomIn, ZoomOut, Check, X, Crop, Move } from 'lucide-react';
import { AspectRatioType, GuessItem } from '../types';

export interface PendingFileItem {
  file: File;
  previewUrl: string;
}

interface ImageEditorModalProps {
  queue: PendingFileItem[];
  currentIndex: number;
  onSaveCurrent: (item: GuessItem) => void;
  onSkipCurrent: () => void;
  onCancelAll: () => void;
}

export const ImageEditorModal: React.FC<ImageEditorModalProps> = ({
  queue,
  currentIndex,
  onSaveCurrent,
  onSkipCurrent,
  onCancelAll,
}) => {
  const currentItem = queue[currentIndex];
  const [name, setName] = useState('');
  const [rotation, setRotation] = useState<number>(0); // 0, 90, 180, 270
  const [aspectRatio, setAspectRatio] = useState<AspectRatioType>('1:1');
  const [zoom, setZoom] = useState<number>(1);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const panStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const imageObjRef = useRef<HTMLImageElement | null>(null);
  const [imageLoaded, setImageLoaded] = useState(false);
  const inputRef = useRef<HTMLInputElement | null>(null);

  // Initialize/reset state whenever current item changes
  useEffect(() => {
    if (!currentItem) return;

    // Never auto-fill filename or numeric IDs like 118016; always start blank so host explicitly enters answer
    setName('');

    setRotation(0);
    setZoom(1);
    setPan({ x: 0, y: 0 });
    setAspectRatio('1:1');
    setImageLoaded(false);

    const img = new Image();
    img.src = currentItem.previewUrl;
    img.onload = () => {
      imageObjRef.current = img;
      setImageLoaded(true);
    };

    // Auto-focus input after modal renders
    const timer = setTimeout(() => {
      inputRef.current?.focus();
    }, 300);
    return () => clearTimeout(timer);
  }, [currentIndex, currentItem]);

  // Compute crop box aspect ratio width/height proportions
  const getAspectRatioProportions = useCallback((ratio: AspectRatioType, origW: number, origH: number) => {
    switch (ratio) {
      case '1:1':
        return { w: 1, h: 1 };
      case '4:3':
        return { w: 4, h: 3 };
      case '16:9':
        return { w: 16, h: 9 };
      case 'free':
      default:
        return { w: origW || 1, h: origH || 1 };
    }
  }, []);

  // Draw the preview onto the interactive canvas
  const drawPreview = useCallback(() => {
    const canvas = canvasRef.current;
    const img = imageObjRef.current;
    if (!canvas || !img || !imageLoaded) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Viewport preview size
    const viewWidth = canvas.width;
    const viewHeight = canvas.height;

    ctx.clearRect(0, 0, viewWidth, viewHeight);

    // Save state
    ctx.save();

    // Fill background with slate dark
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, viewWidth, viewHeight);

    // Center of canvas
    const centerX = viewWidth / 2;
    const centerY = viewHeight / 2;

    // Determine target crop frame dimension inside canvas view
    const margin = 24;
    const maxCropW = viewWidth - margin * 2;
    const maxCropH = viewHeight - margin * 2;
    const proportions = getAspectRatioProportions(aspectRatio, img.width, img.height);
    const aspect = proportions.w / proportions.h;

    let cropW: number;
    let cropH: number;

    if (maxCropW / maxCropH > aspect) {
      cropH = maxCropH;
      cropW = maxCropH * aspect;
    } else {
      cropW = maxCropW;
      cropH = maxCropW / aspect;
    }

    const cropX = centerX - cropW / 2;
    const cropY = centerY - cropH / 2;

    // Clip to crop area so user sees exact framed output
    ctx.save();
    ctx.beginPath();
    ctx.rect(cropX, cropY, cropW, cropH);
    ctx.clip();

    // Dark backdrop for clipped area
    ctx.fillStyle = '#020617';
    ctx.fillRect(cropX, cropY, cropW, cropH);

    // Transformation for image: translation to center + pan + rotation + zoom
    ctx.translate(centerX + pan.x, centerY + pan.y);
    ctx.rotate((rotation * Math.PI) / 180);
    ctx.scale(zoom, zoom);

    // Swap dimensions if rotated 90 or 270 for fitting base scale
    const isRotatedQuarter = rotation === 90 || rotation === 270;
    const effectiveImgW = isRotatedQuarter ? img.height : img.width;
    const effectiveImgH = isRotatedQuarter ? img.width : img.height;

    // Scale image to cover the crop box at zoom = 1
    const scale = Math.max(cropW / effectiveImgW, cropH / effectiveImgH);
    const drawW = img.width * scale;
    const drawH = img.height * scale;

    ctx.drawImage(img, -drawW / 2, -drawH / 2, drawW, drawH);

    ctx.restore(); // Remove clip

    // Draw dark vignette overlay outside the crop box
    ctx.fillStyle = 'rgba(2, 6, 23, 0.75)';
    ctx.beginPath();
    ctx.rect(0, 0, viewWidth, viewHeight);
    ctx.rect(cropX, cropY, cropW, cropH);
    ctx.fill('evenodd');

    // Draw crop box border & rule-of-thirds grid
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 2;
    ctx.strokeRect(cropX, cropY, cropW, cropH);

    // Subtle rule of thirds lines
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    // vertical lines
    ctx.moveTo(cropX + cropW / 3, cropY);
    ctx.lineTo(cropX + cropW / 3, cropY + cropH);
    ctx.moveTo(cropX + (cropW * 2) / 3, cropY);
    ctx.lineTo(cropX + (cropW * 2) / 3, cropY + cropH);
    // horizontal lines
    ctx.moveTo(cropX, cropY + cropH / 3);
    ctx.lineTo(cropX + cropW, cropY + cropH / 3);
    ctx.moveTo(cropX, cropY + (cropH * 2) / 3);
    ctx.lineTo(cropX + cropW, cropY + (cropH * 2) / 3);
    ctx.stroke();

    // Corner guides
    const cornerSize = 14;
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 3;
    ctx.beginPath();
    // Top-left
    ctx.moveTo(cropX, cropY + cornerSize);
    ctx.lineTo(cropX, cropY);
    ctx.lineTo(cropX + cornerSize, cropY);
    // Top-right
    ctx.moveTo(cropX + cropW - cornerSize, cropY);
    ctx.lineTo(cropX + cropW, cropY);
    ctx.lineTo(cropX + cropW, cropY + cornerSize);
    // Bottom-left
    ctx.moveTo(cropX, cropY + cropH - cornerSize);
    ctx.lineTo(cropX, cropY + cropH);
    ctx.lineTo(cropX + cornerSize, cropY + cropH);
    // Bottom-right
    ctx.moveTo(cropX + cropW - cornerSize, cropY + cropH);
    ctx.lineTo(cropX + cropW, cropY + cropH);
    ctx.lineTo(cropX + cropW, cropY + cropH - cornerSize);
    ctx.stroke();

    ctx.restore();
  }, [rotation, aspectRatio, zoom, pan, imageLoaded, getAspectRatioProportions]);

  // Redraw when settings change
  useEffect(() => {
    drawPreview();
  }, [drawPreview]);

  // Handle pointer down (touch or mouse) for pan
  const handlePointerDown = (e: React.PointerEvent) => {
    setIsDragging(true);
    dragStartRef.current = { x: e.clientX, y: e.clientY };
    panStartRef.current = { ...pan };
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    const dx = e.clientX - dragStartRef.current.x;
    const dy = e.clientY - dragStartRef.current.y;
    setPan({
      x: panStartRef.current.x + dx,
      y: panStartRef.current.y + dy,
    });
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    setIsDragging(false);
    try {
      (e.target as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {
      // ignore
    }
  };

  // Rotate 90 degrees
  const handleRotate = (deg: number) => {
    setRotation((prev) => (prev + deg + 360) % 360);
    // Reset pan slightly to keep centered
    setPan({ x: 0, y: 0 });
  };

  // Generate final cropped & rotated image data URL
  const exportFinalImage = (): string => {
    const img = imageObjRef.current;
    if (!img) return currentItem.previewUrl;

    // High resolution output canvas (max 800x800 for mobile snappy performance)
    const proportions = getAspectRatioProportions(aspectRatio, img.width, img.height);
    const targetSize = 800;
    const aspect = proportions.w / proportions.h;

    let outW: number;
    let outH: number;

    if (aspect >= 1) {
      outW = targetSize;
      outH = Math.round(targetSize / aspect);
    } else {
      outH = targetSize;
      outW = Math.round(targetSize * aspect);
    }

    const outCanvas = document.createElement('canvas');
    outCanvas.width = outW;
    outCanvas.height = outH;
    const outCtx = outCanvas.getContext('2d');
    if (!outCtx) return currentItem.previewUrl;

    // Fill neutral dark backdrop
    outCtx.fillStyle = '#020617';
    outCtx.fillRect(0, 0, outW, outH);

    // Apply the exact same transformation
    outCtx.save();
    outCtx.translate(outW / 2, outH / 2);

    // The scale in the preview was relative to the preview canvas crop box.
    // Calculate preview crop size:
    const canvas = canvasRef.current;
    const previewW = canvas?.width || 360;
    const previewH = canvas?.height || 360;
    const margin = 24;
    const maxCropW = previewW - margin * 2;
    const maxCropH = previewH - margin * 2;

    let prevCropW: number;
    let prevCropH: number;
    if (maxCropW / maxCropH > aspect) {
      prevCropH = maxCropH;
      prevCropW = maxCropH * aspect;
    } else {
      prevCropW = maxCropW;
      prevCropH = maxCropW / aspect;
    }

    const scaleFactor = outW / prevCropW;

    outCtx.translate(pan.x * scaleFactor, pan.y * scaleFactor);
    outCtx.rotate((rotation * Math.PI) / 180);
    outCtx.scale(zoom, zoom);

    const isRotatedQuarter = rotation === 90 || rotation === 270;
    const effectiveImgW = isRotatedQuarter ? img.height : img.width;
    const effectiveImgH = isRotatedQuarter ? img.width : img.height;

    const baseScale = Math.max(outW / effectiveImgW, outH / effectiveImgH);
    const drawW = img.width * baseScale;
    const drawH = img.height * baseScale;

    outCtx.drawImage(img, -drawW / 2, -drawH / 2, drawW, drawH);
    outCtx.restore();

    return outCanvas.toDataURL('image/jpeg', 0.88);
  };

  const handleSave = () => {
    const trimmedName = name.trim();
    if (!trimmedName) {
      inputRef.current?.focus();
      return;
    }

    const finalImageDataUrl = exportFinalImage();

    const newItem: GuessItem = {
      id: `img-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      name: trimmedName,
      imageDataUrl: finalImageDataUrl,
      createdAt: Date.now(),
    };

    onSaveCurrent(newItem);
  };

  const isLast = currentIndex === queue.length - 1;

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-slate-950/95 backdrop-blur-md overflow-y-auto">
      {/* Top Header */}
      <header className="sticky top-0 z-10 flex items-center justify-between px-4 py-3 bg-slate-900/90 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <span className="font-bold text-base tracking-tight text-white">Edit & Label Image</span>
          <span className="text-xs text-slate-400 font-medium px-2 py-0.5 rounded-full bg-slate-800">
            {currentIndex + 1} of {queue.length}
          </span>
        </div>
        <button
          onClick={onCancelAll}
          aria-label="Cancel"
          className="min-h-[44px] min-w-[44px] flex items-center justify-center text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </header>

      {/* Editor Content Area */}
      <div className="flex-1 max-w-md w-full mx-auto px-4 py-3 flex flex-col gap-4">
        {/* Step 1: Crop & Framing Preview Canvas */}
        <div className="relative w-full aspect-square max-h-[360px] mx-auto rounded-2xl overflow-hidden shadow-2xl border border-slate-800 bg-slate-900">
          <canvas
            ref={canvasRef}
            width={360}
            height={360}
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            onPointerCancel={handlePointerUp}
            className="w-full h-full object-contain cursor-grab active:cursor-grabbing touch-none select-none"
          />

          {/* Move/Drag Guide Hint */}
          <div className="absolute top-2 left-2 flex items-center gap-1.5 px-2 py-1 rounded-md bg-slate-950/70 text-[11px] text-slate-300 font-medium pointer-events-none">
            <Move className="w-3 h-3 text-cyan-400" />
            <span>Drag to frame</span>
          </div>

          {/* Current rotation indicator */}
          {rotation !== 0 && (
            <div className="absolute top-2 right-2 px-2 py-1 rounded-md bg-slate-950/70 text-[11px] text-cyan-400 font-bold pointer-events-none">
              {rotation}°
            </div>
          )}
        </div>

        {/* Editing Tool Controls */}
        <div className="bg-slate-900/80 rounded-2xl p-3 border border-slate-800/80 space-y-3">
          {/* Rotate Tools */}
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider">Rotate</span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => handleRotate(-90)}
                className="min-h-[44px] px-3.5 flex items-center gap-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold active:scale-95 transition-all"
              >
                <RotateCcw className="w-4 h-4 text-cyan-400" />
                <span>90° Left</span>
              </button>
              <button
                type="button"
                onClick={() => handleRotate(90)}
                className="min-h-[44px] px-3.5 flex items-center gap-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold active:scale-95 transition-all"
              >
                <RotateCw className="w-4 h-4 text-cyan-400" />
                <span>90° Right</span>
              </button>
            </div>
          </div>

          {/* Zoom Slider */}
          <div className="flex items-center gap-3 pt-1 border-t border-slate-800/50">
            <ZoomOut className="w-4 h-4 text-slate-400 shrink-0" />
            <input
              type="range"
              min="1"
              max="3"
              step="0.05"
              value={zoom}
              onChange={(e) => setZoom(parseFloat(e.target.value))}
              aria-label="Image Zoom"
              className="w-full accent-cyan-500 h-2 bg-slate-800 rounded-lg cursor-pointer"
            />
            <ZoomIn className="w-4 h-4 text-slate-400 shrink-0" />
            <span className="text-xs font-mono text-slate-400 w-9 text-right tabular-nums">
              {zoom.toFixed(1)}x
            </span>
          </div>

          {/* Aspect Ratio Framing */}
          <div className="flex items-center justify-between gap-2 pt-1 border-t border-slate-800/50">
            <div className="flex items-center gap-1 text-xs font-semibold text-slate-300 uppercase tracking-wider">
              <Crop className="w-3.5 h-3.5 text-cyan-400" />
              <span>Frame</span>
            </div>
            <div className="flex items-center gap-1.5">
              {(['1:1', '4:3', '16:9', 'free'] as AspectRatioType[]).map((ratio) => (
                <button
                  key={ratio}
                  type="button"
                  onClick={() => setAspectRatio(ratio)}
                  className={`min-h-[38px] px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors ${
                    aspectRatio === ratio
                      ? 'bg-cyan-500 text-slate-950 shadow-sm shadow-cyan-500/30'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {ratio === 'free' ? 'Orig' : ratio}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Name Input */}
        <div className="bg-slate-900/80 rounded-2xl p-3 border border-slate-800/80">
          <input
            id="image-name-input"
            ref={inputRef}
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                handleSave();
              }
            }}
            aria-label="Image name"
            className="w-full min-h-[50px] px-4 rounded-xl bg-slate-950 border border-slate-700 text-white text-base font-semibold focus:outline-none focus:ring-2 focus:ring-cyan-400 focus:border-transparent transition-all"
          />
        </div>

        {/* Action Buttons in Easy One-Hand Reach Zone */}
        <div className="pt-1 pb-6 space-y-2.5">
          <button
            type="button"
            onClick={handleSave}
            disabled={!name.trim()}
            className="w-full min-h-[52px] rounded-2xl bg-cyan-500 hover:bg-cyan-400 disabled:opacity-40 disabled:hover:bg-cyan-500 text-slate-950 font-bold text-base flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20 active:scale-[0.98] transition-all cursor-pointer"
          >
            <Check className="w-5 h-5 stroke-[2.5]" />
            <span>{isLast ? 'Save & Finish' : 'Save & Next Image'}</span>
          </button>

          {queue.length > 1 && (
            <button
              type="button"
              onClick={onSkipCurrent}
              className="w-full min-h-[44px] rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 text-xs font-semibold flex items-center justify-center transition-colors"
            >
              Skip this image
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
