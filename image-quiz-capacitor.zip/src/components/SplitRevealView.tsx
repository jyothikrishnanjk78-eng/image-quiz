import React from 'react';
import { GuessItem } from '../types';

interface SplitRevealViewProps {
  item: GuessItem;
  isRevealed: boolean;
  onToggleReveal: () => void;
}

export const SplitRevealView: React.FC<SplitRevealViewProps> = ({
  item,
  isRevealed,
  onToggleReveal,
}) => {
  return (
    <div className="w-full flex flex-col items-center select-none">
      {/* 3D Perspective Card Container */}
      <div className="w-full max-w-sm aspect-square perspective-1000">
        <div
          role="button"
          tabIndex={0}
          onClick={onToggleReveal}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              onToggleReveal();
            }
          }}
          aria-label={isRevealed ? `Card flipped, answer: ${item.name}` : 'Tap image to flip card'}
          className={`relative w-full h-full rounded-3xl preserve-3d transition-transform duration-[420ms] ease-in-out cursor-pointer shadow-2xl focus:outline-none focus-visible:ring-4 focus-visible:ring-cyan-400 ${
            isRevealed ? 'rotate-y-180' : ''
          }`}
          style={{
            transform: isRevealed ? 'rotateY(180deg)' : 'rotateY(0deg)',
          }}
        >
          {/* FRONT SIDE: Shows uploaded image normally without overlays */}
          <div className="absolute inset-0 w-full h-full rounded-3xl overflow-hidden backface-hidden bg-slate-900 border-2 border-slate-800 shadow-xl">
            <img
              src={item.imageDataUrl}
              alt=""
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover rounded-3xl"
            />
          </div>

          {/* BACK SIDE: Image name centered on the back, no other text */}
          <div
            className="absolute inset-0 w-full h-full rounded-3xl backface-hidden bg-slate-900 border-2 border-slate-800 p-6 flex items-center justify-center text-center shadow-2xl"
            style={{
              transform: 'rotateY(180deg)',
            }}
          >
            <span className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight break-words max-w-full leading-tight">
              {item.name}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
