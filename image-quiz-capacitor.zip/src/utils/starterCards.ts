import { GuessItem } from '../types';

export function createStarterCards(): GuessItem[] {
  const cards: { name: string; draw: (ctx: CanvasRenderingContext2D, w: number, h: number) => void }[] = [
    {
      name: 'Iron Man',
      draw: (ctx, w, h) => {
        // Dramatic dark crimson and gold background
        const grad = ctx.createRadialGradient(w / 2, h / 2, 40, w / 2, h / 2, w / 2);
        grad.addColorStop(0, '#850000');
        grad.addColorStop(1, '#2b0000');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, w, h);

        // Arc reactor glow
        const reactorGlow = ctx.createRadialGradient(w / 2, h / 2, 20, w / 2, h / 2, 120);
        reactorGlow.addColorStop(0, 'rgba(100, 220, 255, 0.9)');
        reactorGlow.addColorStop(0.4, 'rgba(0, 160, 255, 0.4)');
        reactorGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = reactorGlow;
        ctx.fillRect(0, 0, w, h);

        // Mask Faceplate geometry (Stylized helmet)
        ctx.save();
        ctx.translate(w / 2, h / 2 - 20);

        // Crimson Helmet outer contour
        ctx.beginPath();
        ctx.moveTo(-90, -110);
        ctx.bezierCurveTo(-110, -50, -100, 70, -60, 130);
        ctx.lineTo(60, 130);
        ctx.bezierCurveTo(100, 70, 110, -50, 90, -110);
        ctx.bezierCurveTo(60, -140, -60, -140, -90, -110);
        ctx.fillStyle = '#b81414';
        ctx.fill();
        ctx.lineWidth = 4;
        ctx.strokeStyle = '#5a0606';
        ctx.stroke();

        // Golden Faceplate
        ctx.beginPath();
        ctx.moveTo(-60, -70);
        ctx.lineTo(60, -70);
        ctx.lineTo(75, 10);
        ctx.lineTo(50, 80);
        ctx.lineTo(35, 115);
        ctx.lineTo(-35, 115);
        ctx.lineTo(-50, 80);
        ctx.lineTo(-75, 10);
        ctx.closePath();
        ctx.fillStyle = '#e8b923';
        ctx.fill();
        ctx.strokeStyle = '#9e790a';
        ctx.stroke();

        // Glowing blue eyes
        ctx.fillStyle = '#e0f7ff';
        ctx.shadowColor = '#00c3ff';
        ctx.shadowBlur = 18;

        // Left eye
        ctx.beginPath();
        ctx.moveTo(-52, -15);
        ctx.lineTo(-20, -10);
        ctx.lineTo(-24, -2);
        ctx.lineTo(-50, -8);
        ctx.closePath();
        ctx.fill();

        // Right eye
        ctx.beginPath();
        ctx.moveTo(52, -15);
        ctx.lineTo(20, -10);
        ctx.lineTo(24, -2);
        ctx.lineTo(50, -8);
        ctx.closePath();
        ctx.fill();

        ctx.restore();
      },
    },
    {
      name: 'Eiffel Tower',
      draw: (ctx, w, h) => {
        // Paris sunset sky
        const grad = ctx.createLinearGradient(0, 0, 0, h);
        grad.addColorStop(0, '#1a103c');
        grad.addColorStop(0.5, '#692758');
        grad.addColorStop(0.8, '#de6b48');
        grad.addColorStop(1, '#f7c06d');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, w, h);

        // Tower silhouette
        ctx.save();
        ctx.translate(w / 2, h / 2 + 50);

        ctx.fillStyle = '#181124';
        // Base legs
        ctx.beginPath();
        ctx.moveTo(-110, 140);
        ctx.lineTo(-75, 40);
        ctx.lineTo(-35, 40);
        ctx.quadraticCurveTo(0, 80, 35, 40);
        ctx.lineTo(75, 40);
        ctx.lineTo(110, 140);
        ctx.lineTo(80, 140);
        ctx.lineTo(50, 55);
        ctx.quadraticCurveTo(0, 95, -50, 55);
        ctx.lineTo(-80, 140);
        ctx.closePath();
        ctx.fill();

        // Platform 1
        ctx.fillRect(-70, 35, 140, 10);

        // Mid section
        ctx.beginPath();
        ctx.moveTo(-50, 35);
        ctx.lineTo(-25, -60);
        ctx.lineTo(25, -60);
        ctx.lineTo(50, 35);
        ctx.closePath();
        ctx.fill();

        // Platform 2
        ctx.fillRect(-35, -65, 70, 8);

        // Spire section
        ctx.beginPath();
        ctx.moveTo(-20, -65);
        ctx.lineTo(-4, -180);
        ctx.lineTo(4, -180);
        ctx.lineTo(20, -65);
        ctx.closePath();
        ctx.fill();

        // Tip antenna & beacon light
        ctx.fillRect(-2, -210, 4, 30);
        ctx.fillStyle = '#fff4bd';
        ctx.shadowColor = '#ffe269';
        ctx.shadowBlur = 25;
        ctx.beginPath();
        ctx.arc(0, -210, 6, 0, Math.PI * 2);
        ctx.fill();

        ctx.restore();
      },
    },
    {
      name: 'Pikachu',
      draw: (ctx, w, h) => {
        // Bright playful lightning background
        const grad = ctx.createLinearGradient(0, 0, w, h);
        grad.addColorStop(0, '#fde047');
        grad.addColorStop(1, '#eab308');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, w, h);

        ctx.save();
        ctx.translate(w / 2, h / 2 + 10);

        // Ears
        // Left Ear
        ctx.save();
        ctx.rotate(-0.35);
        ctx.beginPath();
        ctx.ellipse(-65, -120, 24, 75, -0.2, 0, Math.PI * 2);
        ctx.fillStyle = '#facc15';
        ctx.fill();
        // Black tip
        ctx.beginPath();
        ctx.ellipse(-78, -170, 18, 28, -0.2, 0, Math.PI * 2);
        ctx.fillStyle = '#1e1b18';
        ctx.fill();
        ctx.restore();

        // Right Ear
        ctx.save();
        ctx.rotate(0.35);
        ctx.beginPath();
        ctx.ellipse(65, -120, 24, 75, 0.2, 0, Math.PI * 2);
        ctx.fillStyle = '#facc15';
        ctx.fill();
        // Black tip
        ctx.beginPath();
        ctx.ellipse(78, -170, 18, 28, 0.2, 0, Math.PI * 2);
        ctx.fillStyle = '#1e1b18';
        ctx.fill();
        ctx.restore();

        // Head
        ctx.beginPath();
        ctx.arc(0, -10, 100, 0, Math.PI * 2);
        ctx.fillStyle = '#facc15';
        ctx.fill();

        // Red cheeks
        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        ctx.arc(-70, 20, 26, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(70, 20, 26, 0, Math.PI * 2);
        ctx.fill();

        // Eyes
        ctx.fillStyle = '#18181b';
        ctx.beginPath();
        ctx.arc(-42, -22, 16, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(42, -22, 16, 0, Math.PI * 2);
        ctx.fill();

        // Eye glints
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(-46, -26, 6, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(38, -26, 6, 0, Math.PI * 2);
        ctx.fill();

        // Tiny nose
        ctx.fillStyle = '#18181b';
        ctx.beginPath();
        ctx.arc(0, -5, 3.5, 0, Math.PI * 2);
        ctx.fill();

        // Happy mouth
        ctx.strokeStyle = '#18181b';
        ctx.lineWidth = 4;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.arc(-14, 15, 14, 0.2, Math.PI - 0.2);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(14, 15, 14, 0.2, Math.PI - 0.2);
        ctx.stroke();

        ctx.restore();
      },
    },
  ];

  return cards.map((c, i) => {
    const canvas = document.createElement('canvas');
    canvas.width = 600;
    canvas.height = 600;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      c.draw(ctx, 600, 600);
    }
    return {
      id: `starter-${i}-${Date.now()}`,
      name: c.name,
      imageDataUrl: canvas.toDataURL('image/jpeg', 0.9),
      createdAt: Date.now() - (cards.length - i) * 1000,
      width: 600,
      height: 600,
    };
  });
}
