import React, { useState, useEffect } from 'react';
import { ArrowRight, RotateCcw, Home, Sparkles } from 'lucide-react';
import { GuessItem } from '../types';
import { SplitRevealView } from './SplitRevealView';

interface GameScreenProps {
  items: GuessItem[];
  onExit: () => void;
}

// Fisher-Yates random shuffle
function shuffleArray<T>(array: T[]): T[] {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

export const GameScreen: React.FC<GameScreenProps> = ({ items, onExit }) => {
  const [shuffledDeck, setShuffledDeck] = useState<GuessItem[]>([]);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isRevealed, setIsRevealed] = useState<boolean>(false);
  const [isGameOver, setIsGameOver] = useState<boolean>(false);
  const [isTransitioning, setIsTransitioning] = useState<boolean>(false);

  // Initialize and shuffle on first mount or reset
  const startNewGame = () => {
    const shuffled = shuffleArray(items);
    setShuffledDeck(shuffled);
    setCurrentIndex(0);
    setIsRevealed(false);
    setIsGameOver(false);
    setIsTransitioning(false);
  };

  useEffect(() => {
    startNewGame();
  }, [items]);

  const handleToggleReveal = () => {
    if (isTransitioning) return;
    setIsRevealed((prev) => !prev);
  };

  const handleNext = () => {
    if (isTransitioning) return;
    setIsTransitioning(true);

    if (currentIndex + 1 < shuffledDeck.length) {
      // Smoothly reset the card rotation back toward the front
      setIsRevealed(false);

      // At edge-on point of flip (210ms), advance to next random image so it lands on front
      setTimeout(() => {
        setCurrentIndex((prev) => prev + 1);
        setIsTransitioning(false);
      }, 210);
    } else {
      // All images have been shown
      setIsRevealed(false);
      setTimeout(() => {
        setIsGameOver(true);
        setIsTransitioning(false);
      }, 350);
    }
  };

  const handlePlayAgain = () => {
    startNewGame();
  };

  // If no items available (fallback safe check)
  if (items.length === 0) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 text-center">
        <p className="text-slate-400 mb-4">No images to play with.</p>
        <button
          onClick={onExit}
          className="min-h-[48px] px-6 rounded-2xl bg-cyan-500 text-slate-950 font-bold"
        >
          Back to Home
        </button>
      </div>
    );
  }

  // END OF GAME SCREEN
  if (isGameOver) {
    return (
      <main className="min-h-screen flex flex-col items-center justify-between p-6 max-w-md mx-auto text-center">
        {/* Top quiet exit */}
        <div className="w-full flex justify-end pt-2">
          <button
            onClick={onExit}
            aria-label="Return to home"
            className="min-h-[44px] min-w-[44px] flex items-center justify-center text-slate-400 hover:text-white transition-colors"
          >
            <Home className="w-6 h-6" />
          </button>
        </div>

        {/* Center celebratory message */}
        <div className="my-auto flex flex-col items-center py-8">
          <div className="w-24 h-24 mb-6 rounded-3xl bg-cyan-500/10 border-2 border-cyan-400/40 flex items-center justify-center shadow-[0_0_40px_rgba(6,182,212,0.25)]">
            <Sparkles className="w-12 h-12 text-cyan-400" />
          </div>

          <h1 className="text-4xl sm:text-5xl font-black text-white tracking-tight mb-3">
            GAME OVER 🎉
          </h1>

          <p className="text-base text-slate-400 max-w-xs mb-2">
            Every image has been shown! Great job guessing.
          </p>

          <span className="text-xs font-semibold text-cyan-400 uppercase tracking-widest px-3 py-1 rounded-full bg-cyan-950/60 border border-cyan-800">
            {items.length} of {items.length} Images Completed
          </span>
        </div>

        {/* Large thumb-zone PLAY AGAIN button */}
        <div className="w-full space-y-3 pb-8">
          <button
            onClick={handlePlayAgain}
            className="w-full min-h-[60px] rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-lg flex items-center justify-center gap-2.5 shadow-xl shadow-cyan-500/25 active:scale-[0.98] transition-all cursor-pointer"
          >
            <RotateCcw className="w-6 h-6 stroke-[2.5]" />
            <span>PLAY AGAIN</span>
          </button>

          <button
            onClick={onExit}
            className="w-full min-h-[48px] rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 font-semibold text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <Home className="w-4 h-4" />
            <span>Upload & Manage Images</span>
          </button>
        </div>
      </main>
    );
  }

  const currentItem = shuffledDeck[currentIndex];

  if (!currentItem) {
    return null;
  }

  return (
    <main className="min-h-screen flex flex-col justify-between p-4 max-w-md mx-auto select-none">
      {/* Top Bar: Progress and Home icon */}
      <header className="flex items-center justify-between py-2 border-b border-slate-900">
        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-cyan-400 font-bold uppercase tracking-wider">
            Image {currentIndex + 1} of {shuffledDeck.length}
          </span>
        </div>

        <button
          onClick={onExit}
          title="Exit game"
          aria-label="Exit game to home"
          className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-400 hover:text-white hover:bg-slate-900 transition-colors"
        >
          <Home className="w-5 h-5" />
        </button>
      </header>

      {/* Main Center Area: Card Flip Reveal Image */}
      <section aria-label="Current image" className="my-auto py-4 flex flex-col items-center justify-center w-full">
        <SplitRevealView
          item={currentItem}
          isRevealed={isRevealed}
          onToggleReveal={handleToggleReveal}
        />
      </section>

      {/* Bottom Action Controls: Shows NEXT → button after the flip */}
      <footer className="w-full pt-2 pb-6 min-h-[88px] flex flex-col items-center justify-center">
        {isRevealed && (
          <button
            onClick={handleNext}
            autoFocus
            className="w-full min-h-[60px] rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-lg flex items-center justify-center gap-2.5 shadow-xl shadow-cyan-500/30 active:scale-[0.98] transition-all cursor-pointer animate-bounce-subtle"
          >
            <span>NEXT →</span>
          </button>
        )}
      </footer>
    </main>
  );
};
