import React, { useRef } from 'react';
import { Upload, Play, Trash2, Image as ImageIcon, Sparkles } from 'lucide-react';
import { GuessItem } from '../types';

interface HomeScreenProps {
  items: GuessItem[];
  onUploadClick: () => void;
  onFilesSelected: (files: FileList) => void;
  onStartGame: () => void;
  onDeleteItem: (id: string) => void;
  onLoadStarterPack: () => void;
  fileInputRef: React.RefObject<HTMLInputElement | null>;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  items,
  onUploadClick,
  onFilesSelected,
  onStartGame,
  onDeleteItem,
  onLoadStarterPack,
  fileInputRef,
}) => {
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onFilesSelected(e.target.files);
      // Reset input so same file can be selected again if needed
      e.target.value = '';
    }
  };

  const hasImages = items.length > 0;

  return (
    <main className="min-h-screen flex flex-col justify-between max-w-md mx-auto p-4 select-none">
      {/* Top Header */}
      <header className="pt-2 pb-4 text-center">
        <h1 className="text-3xl font-black text-white tracking-tight flex items-center justify-center gap-2">
          <span>Image Quiz</span>
        </h1>
      </header>

      {/* Hidden native file input for gallery selection */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        multiple
        className="hidden"
      />

      {/* Main Body: Uploaded Images List/Grid */}
      <div className="flex-1 flex flex-col my-2 overflow-y-auto max-h-[calc(100vh-270px)] pr-0.5">
        <div className="flex items-center justify-between mb-3 px-1">
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wider">
              Uploaded Images
            </h2>
            <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-slate-800 text-cyan-400">
              {items.length}
            </span>
          </div>

          {items.length > 0 && (
            <button
              onClick={onUploadClick}
              className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 py-1 px-2.5 rounded-lg bg-slate-900 border border-cyan-500/20 active:scale-95 transition-all"
            >
              + Add More
            </button>
          )}
        </div>

        {items.length === 0 ? (
          /* Empty state */
          <div className="my-auto flex flex-col items-center justify-center p-6 text-center rounded-3xl bg-slate-900/60 border border-slate-800/80">
            <div className="w-16 h-16 mb-4 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
              <ImageIcon className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold text-white mb-1">No Images Yet</h3>
            <p className="text-xs text-slate-400 max-w-xs mb-6">
              Upload pictures from your phone gallery. You can crop, rotate, and label them for contestants to guess!
            </p>

            <div className="w-full space-y-2.5">
              <button
                onClick={onUploadClick}
                className="w-full min-h-[48px] rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20 active:scale-95 transition-all cursor-pointer"
              >
                <Upload className="w-4 h-4 stroke-[2.5]" />
                <span>UPLOAD IMAGES</span>
              </button>

              <button
                onClick={onLoadStarterPack}
                className="w-full min-h-[44px] rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-700 text-slate-300 font-semibold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <span>Load 3 Sample Cards (Iron Man, Eiffel, Pikachu)</span>
              </button>
            </div>
          </div>
        ) : (
          /* Images Grid / List */
          <div className="grid grid-cols-2 gap-3 pb-4">
            {items.map((item) => (
              <div
                key={item.id}
                className="group relative rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden flex flex-col shadow-md"
              >
                {/* Image Aspect Box */}
                <div className="relative aspect-square w-full bg-slate-950 overflow-hidden">
                  <img
                    src={item.imageDataUrl}
                    alt={item.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  {/* Delete button (convenient for host management) */}
                  <button
                    onClick={() => onDeleteItem(item.id)}
                    aria-label={`Delete ${item.name}`}
                    className="absolute top-2 right-2 min-h-[36px] min-w-[36px] flex items-center justify-center rounded-xl bg-slate-950/80 hover:bg-red-500 text-slate-300 hover:text-white backdrop-blur-sm transition-all"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                {/* Name Label */}
                <div className="p-2.5 bg-slate-900 border-t border-slate-800/80">
                  <p className="text-xs font-semibold text-white truncate" title={item.name}>
                    {item.name}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Main Controls Anchored in Thumb Zone */}
      <footer className="w-full space-y-3 pt-3 pb-4 bg-slate-950/90 border-t border-slate-900">
        {/* Primary Action 1: START button */}
        <button
          onClick={onStartGame}
          disabled={!hasImages}
          className="w-full min-h-[64px] rounded-2xl bg-cyan-500 hover:bg-cyan-400 disabled:opacity-40 disabled:hover:bg-cyan-500 text-slate-950 font-black text-xl flex items-center justify-center gap-3 shadow-xl shadow-cyan-500/25 active:scale-[0.98] transition-all cursor-pointer"
        >
          <Play className="w-6 h-6 fill-current stroke-[2]" />
          <span>START {hasImages ? `(${items.length})` : ''}</span>
        </button>

        {/* Primary Action 2: UPLOAD IMAGES button */}
        <button
          onClick={onUploadClick}
          className="w-full min-h-[52px] rounded-2xl bg-slate-900 hover:bg-slate-850 border-2 border-slate-800 hover:border-cyan-500/40 text-white font-bold text-base flex items-center justify-center gap-2.5 active:scale-[0.98] transition-all cursor-pointer"
        >
          <Upload className="w-5 h-5 text-cyan-400 stroke-[2.5]" />
          <span>UPLOAD IMAGES</span>
        </button>
      </footer>
    </main>
  );
};
