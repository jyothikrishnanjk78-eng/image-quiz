/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { GuessItem } from './types';
import {
  getAllGuessItems,
  saveGuessItem,
  saveManyGuessItems,
  deleteGuessItem,
} from './services/storage';
import { createStarterCards } from './utils/starterCards';
import { HomeScreen } from './components/HomeScreen';
import { GameScreen } from './components/GameScreen';
import { ImageEditorModal, PendingFileItem } from './components/ImageEditorModal';

export default function App() {
  const [items, setItems] = useState<GuessItem[]>([]);
  const [screen, setScreen] = useState<'home' | 'game'>('home');
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // File Upload Queue & Editor State
  const [editorQueue, setEditorQueue] = useState<PendingFileItem[]>([]);
  const [currentEditIndex, setCurrentEditIndex] = useState<number>(0);
  const [isEditorOpen, setIsEditorOpen] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Load stored images from local IndexedDB on mount
  useEffect(() => {
    async function loadData() {
      try {
        const stored = await getAllGuessItems();
        if (stored.length > 0) {
          setItems(stored);
        } else {
          // On first fresh open, initialize with 3 high quality starter cards (Iron Man, Eiffel Tower, Pikachu)
          // so the host has ready-to-test cards right away!
          const starterPack = createStarterCards();
          await saveManyGuessItems(starterPack);
          setItems(starterPack);
        }
      } catch (err) {
        console.error('Failed to load local offline items:', err);
      } finally {
        setIsLoading(false);
      }
    }
    loadData();
  }, []);

  // Trigger gallery file picker
  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  // Handle files selected from gallery
  const handleFilesSelected = (fileList: FileList) => {
    const files = Array.from(fileList);
    if (files.length === 0) return;

    const queue: PendingFileItem[] = files.map((file) => ({
      file,
      previewUrl: URL.createObjectURL(file),
    }));

    setEditorQueue(queue);
    setCurrentEditIndex(0);
    setIsEditorOpen(true);
  };

  // Save current item from editor
  const handleSaveCurrentEdit = async (newItem: GuessItem) => {
    try {
      await saveGuessItem(newItem);
      setItems((prev) => [newItem, ...prev.filter((i) => i.id !== newItem.id)]);
    } catch (err) {
      console.error('Failed to save item locally:', err);
    }

    // Advance queue
    if (currentEditIndex + 1 < editorQueue.length) {
      setCurrentEditIndex((prev) => prev + 1);
    } else {
      // Finished all items in queue
      cleanupEditor();
    }
  };

  // Skip current item in queue
  const handleSkipCurrentEdit = () => {
    if (currentEditIndex + 1 < editorQueue.length) {
      setCurrentEditIndex((prev) => prev + 1);
    } else {
      cleanupEditor();
    }
  };

  // Cancel remaining queue
  const handleCancelEditor = () => {
    cleanupEditor();
  };

  const cleanupEditor = () => {
    editorQueue.forEach((item) => {
      URL.revokeObjectURL(item.previewUrl);
    });
    setEditorQueue([]);
    setCurrentEditIndex(0);
    setIsEditorOpen(false);
  };

  // Delete an image
  const handleDeleteItem = async (id: string) => {
    try {
      await deleteGuessItem(id);
      setItems((prev) => prev.filter((i) => i.id !== id));
    } catch (err) {
      console.error('Failed to delete item:', err);
    }
  };

  // Load starter pack
  const handleLoadStarterPack = async () => {
    const starterPack = createStarterCards();
    await saveManyGuessItems(starterPack);
    setItems((prev) => [...starterPack, ...prev]);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950 text-slate-400">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 rounded-full border-2 border-cyan-400 border-t-transparent animate-spin" />
          <span className="text-xs font-semibold tracking-wider uppercase text-slate-400">
            Loading Image Quiz...
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans">
      {screen === 'home' ? (
        <HomeScreen
          items={items}
          onUploadClick={handleUploadClick}
          onFilesSelected={handleFilesSelected}
          onStartGame={() => setScreen('game')}
          onDeleteItem={handleDeleteItem}
          onLoadStarterPack={handleLoadStarterPack}
          fileInputRef={fileInputRef}
        />
      ) : (
        <GameScreen
          items={items}
          onExit={() => setScreen('home')}
        />
      )}

      {/* Crop, Rotate & Label Editor Modal */}
      {isEditorOpen && editorQueue.length > 0 && (
        <ImageEditorModal
          queue={editorQueue}
          currentIndex={currentEditIndex}
          onSaveCurrent={handleSaveCurrentEdit}
          onSkipCurrent={handleSkipCurrentEdit}
          onCancelAll={handleCancelEditor}
        />
      )}
    </div>
  );
}
